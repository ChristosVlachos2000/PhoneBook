﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Text.RegularExpressions;

namespace PhoneBookAlepis
{
    public partial class Form1 : Form
    {

        String connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=DatabaseAlepis.mdb";
        OleDbConnection connection;
        private Mp3Player mp3Player = new Mp3Player();
        public Form1()
        {

            InitializeComponent();

        }



        private void Form1_Load(object sender, EventArgs e)
        {

            connection = new OleDbConnection(connectionString);
            disp_data();
            SB();
        }

        public void disp_data()
        {

            connection.Open();

            String query = "select * from Table1";

            OleDbCommand command = new OleDbCommand();

            command.Connection = connection;

            command.CommandText = query;

            OleDbDataAdapter da = new OleDbDataAdapter(command);

            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            connection.Close();

        }

        public static bool IsValidEmailAddress(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }


        public static bool IsValidNumber(string s)
        {
            return Regex.Match(s, @"^(|[0])?[1-9][0-9]{9}$").Success;


        }


        public void SB()
        {


            string m = DateTime.Now.Month.ToString();
            DateTime dt = DateTime.Now;
            string d = dt.Day.ToString();
            Boolean flag = true;
            try
            {
                connection.Open();

                String query = "select FirstName,LastName from Table1 where DayOfBirth='" + d + "' and MonthOfBirth='" + m + "' ";


                OleDbCommand cmd = new OleDbCommand(query);
                cmd.Connection = connection;
                OleDbDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    flag = false;
                    MessageBox.Show("Happy birthday dear");
                    ;
                    MessageBox.Show(reader["FirstName"].ToString() + " " + reader["LastName"].ToString());
                }

                if (flag)
                {
                    MessageBox.Show("No birthdays today");
                }


                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }




        private void Edit_Click(object sender, EventArgs e)
        {
            bool k1 = IsValidEmailAddress(textBox5.Text);

            bool k2 = IsValidNumber(textBox4.Text);



            if (k2 && k1)
            {


                try
                {

                    connection.Open();


                    OleDbCommand command = new OleDbCommand();
                    command.Connection = connection;

                    String query = "update Table1 set [Adress]='" + textBox3.Text + "'  ,[Number]='" + textBox4.Text + "'  ,[Email]='" + textBox5.Text + "'  ,[Image]='" + path1 + "'  ,[Music]='" + path2 + "'  ,[DayOfBirth]='" + numericUpDown1.Value.ToString() + "'  ,[MonthOfBirth]='" + numericUpDown2.Value.ToString() + "'   where [LastName] ='" + textBox2.Text + "' and   [FirstName]='" + textBox1.Text + "'  ";

                    command.CommandText = query;
                    path1 = null;
                    path2 = null;
                    command.ExecuteNonQuery();
                    connection.Close();


                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox5.Text = "";
                    textBox4.Text = "";
                    numericUpDown1.Value = 1;
                    numericUpDown2.Value = 1;
                    pictureBox1.ImageLocation = null;


                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);

                }
                disp_data();
            }
            else
            {
                if (k1 == false)
                {

                    MessageBox.Show("Invalid email!");

                }
                if (k2 == false)
                {
                    MessageBox.Show("Invalid number!");

                }

            }
        }


        private void Delete_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                String query = "delete from Table1 where    FirstName='" + textBox1.Text + "'  AND LastName ='" + textBox2.Text + "' AND Number = '" + textBox4.Text + "'   AND Adress = '" + textBox3.Text + "' AND MonthOfBirth = '" + numericUpDown2.Value.ToString() + "'AND DayOfBirth = '" + numericUpDown1.Value.ToString() + "' ";
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = query;
                command.ExecuteNonQuery();

                connection.Close();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox5.Text = "";
                textBox4.Text = "";
                numericUpDown1.Value = 1;
                numericUpDown2.Value = 1;
                pictureBox1.ImageLocation = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }
            disp_data();
        }

        private void New_Click(object sender, EventArgs e)

        {
            bool k1 = IsValidEmailAddress(textBox5.Text);

            bool k2 = IsValidNumber(textBox4.Text);

            if (k2 && k1)
            {
                connection.Open();

                String query = "insert into Table1 values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + numericUpDown1.Value + "','" + numericUpDown2.Value + "','" + textBox4.Text + "','" + textBox5.Text + "','" + path1 + "','" + path2 + "')";
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = query;
                connection.Close();
                disp_data();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox5.Text = "";
                textBox4.Text = "";
                numericUpDown1.Value = 1;
                numericUpDown2.Value = 1;
                MessageBox.Show("All info inserted with success!");

            }

            else
            {
                if (k1 == false)
                {

                    MessageBox.Show("Invalid email!");

                }
                if (k2 == false)
                {
                    MessageBox.Show("Invalid number!");

                }
                
            }

        }

        private void Search_Click(object sender, EventArgs e)
        {
            String query = "";
            if (textBox2.Text == "" && textBox4.Text == "" && textBox1.Text == "")
            {
                MessageBox.Show("First fill FirstName or LastName or Phonenumber to execute the search thank you!!!");
            }
            else
            {
                try
                {
                    connection.Open();

                    if (textBox1.Text == "" && textBox2.Text == "")
                    {
                        query = "select * from Table1 where Number ='" + textBox4.Text + "'";
                    }
                    else if (textBox1.Text == "" && textBox4.Text == "")
                    {
                        query = "select * from Table1 where LastName ='" + textBox2.Text + "'";
                    }
                    else if (textBox4.Text == "" && textBox2.Text == "")
                    {
                        query = "select * from Table1 where  FirstName ='" + textBox1.Text + "'";
                    }
                   

                    OleDbCommand command = new OleDbCommand();
                    command.Connection = connection;
                    command.CommandText = query;
                    command.ExecuteNonQuery();

                    OleDbDataAdapter da = new OleDbDataAdapter(command);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;

                    connection.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error" + ex);

                }

            }
        }

        private void Play_Click(object sender, EventArgs e)
        {
            mp3Player.play();
        }

        private void Stop_Click(object sender, EventArgs e)
        {
            mp3Player.stop();
        }

        string path2 = null;
        private void button2_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Mp3 Files|*.mp3";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    path2 = ofd.FileName;
                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {

                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                label6.Text = row.Cells["FirstName"].Value.ToString();
                label7.Text = row.Cells["LastName"].Value.ToString();
                label8.Text = row.Cells["Adress"].Value.ToString();
                label9.Text = row.Cells["Email"].Value.ToString();
                label10.Text = row.Cells["Number"].Value.ToString();

                label11.Text = row.Cells["DayOfBirth"].Value.ToString();
                label12.Text = row.Cells["MonthOfBirth"].Value.ToString();
                pictureBox2.ImageLocation = row.Cells["Image"].Value.ToString();
                 

                axWindowsMediaPlayer1.URL = row.Cells["Music"].Value.ToString();

            }
        }

        String path1 = null;
        private void Import_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = "Image files(*.jpg, *.jpeg, *.jpe, *.jfif, *.png)|*.jpg; *.jpeg; *.jpe; *.jfif; *.png";
            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                path1 = ofd.FileName;
               
                pictureBox1.ImageLocation = path1;
            }
        }
    }
    
 }
    


